module.exports = {
    db: 'mongodb+srv://dragdroptask:dragdroptask@cluster0.12gif.mongodb.net/applicants?retryWrites=true&w=majority'
 };